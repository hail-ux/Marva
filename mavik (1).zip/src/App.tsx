import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Mic, MicOff, Volume2, VolumeX, RefreshCw, MessageSquare, Send, Moon, Sun, Sliders } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Initialize Gemini API
const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

interface Message {
  role: 'user' | 'assistant';
  content: string;
  isTyping?: boolean;
}

const SYSTEM_PROMPT = `
You are the AI assistant for Mavik.
Do not repeat greetings like "Hi" or "Hello" for every message.
Respond concisely. Avoid long introductions or unnecessary information.
Focus on the user's question directly. Give examples only if they clarify the point.
Use a friendly, warm British tone (like Tom Holland style).
Explain clearly, in short sentences. Add light humour occasionally if appropriate.
When answering, divide information into small points or steps.
Avoid unnecessary filler.
Focus on clarity and user-friendly style.
Do not use markdown formatting like asterisks or bolding, as this will be read aloud.
`;

export default function App() {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [status, setStatus] = useState('Ready');
  const [transcript, setTranscript] = useState('');
  const [isMuted, setIsMuted] = useState(false);
  const [inputText, setInputText] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [speechRate, setSpeechRate] = useState(1.0);
  const [isTyping, setIsTyping] = useState(false);

  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Scroll to bottom on new messages
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, transcript, isTyping]);

  useEffect(() => {
    // Initialize Speech Recognition
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-GB';

      recognitionRef.current.onstart = () => {
        setIsListening(true);
        setStatus('Listening...');
      };

      recognitionRef.current.onresult = (event: any) => {
        const current = event.resultIndex;
        const transcriptText = event.results[current][0].transcript;
        setTranscript(transcriptText);
        
        if (event.results[current].isFinal) {
          handleUserMessage(transcriptText);
          setTranscript('');
        }
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
        if (status === 'Listening...') setStatus('Ready');
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
        setStatus('Ready');
      };
    }

    // Initialize Speech Synthesis
    synthRef.current = window.speechSynthesis;

    return () => {
      if (recognitionRef.current) recognitionRef.current.stop();
      if (synthRef.current) synthRef.current.cancel();
    };
  }, []);

  const typeEffect = async (text: string) => {
    setIsTyping(true);
    let displayText = '';
    const newMessage: Message = { role: 'assistant', content: '', isTyping: true };
    setMessages(prev => [...prev, newMessage]);

    for (let i = 0; i < text.length; i++) {
      displayText += text[i];
      setMessages(prev => {
        const updated = [...prev];
        updated[updated.length - 1] = { ...updated[updated.length - 1], content: displayText };
        return updated;
      });
      await new Promise(r => setTimeout(r, 15));
    }
    
    setMessages(prev => {
      const updated = [...prev];
      updated[updated.length - 1] = { ...updated[updated.length - 1], isTyping: false };
      return updated;
    });
    setIsTyping(false);
  };

  const handleUserMessage = async (text: string) => {
    if (!text.trim()) return;

    const newUserMessage: Message = { role: 'user', content: text };
    setMessages(prev => [...prev, newUserMessage]);
    setStatus('Thinking...');

    try {
      const chat = genAI.chats.create({
        model: "gemini-3-flash-preview",
        config: {
          systemInstruction: SYSTEM_PROMPT,
        },
        history: messages.map(m => ({
          role: m.role === 'user' ? 'user' : 'model',
          parts: [{ text: m.content }]
        }))
      });

      const result = await chat.sendMessage({ message: text });
      const responseText = result.text || "Sorry, I couldn't generate a response.";
      
      await typeEffect(responseText);
      
      if (!isMuted) {
        speak(responseText);
      } else {
        setStatus('Ready');
      }
    } catch (error) {
      console.error('Error calling Gemini:', error);
      setStatus('Error');
    }
  };

  const speak = (text: string) => {
    if (!synthRef.current) return;
    
    synthRef.current.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-GB';
    utterance.pitch = 1.05;
    utterance.rate = speechRate;
    utterance.volume = 1.0;
    
    utterance.onstart = () => {
      setIsSpeaking(true);
      setStatus('Speaking...');
    };
    
    utterance.onend = () => {
      setIsSpeaking(false);
      setStatus('Ready');
    };

    synthRef.current.speak(utterance);
  };

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      if (synthRef.current) synthRef.current.cancel();
      recognitionRef.current?.start();
    }
  };

  const handleSendText = () => {
    if (inputText.trim()) {
      handleUserMessage(inputText);
      setInputText('');
    }
  };

  const resetConversation = () => {
    setMessages([]);
    setStatus('Ready');
    setTranscript('');
    if (synthRef.current) synthRef.current.cancel();
  };

  const quickButtons = [
    "Hello!",
    "Tell me a joke",
    "Explain AI",
    "Give an example",
    "Fun fact"
  ];

  return (
    <div className={`min-h-screen flex items-center justify-center p-4 font-sans transition-colors duration-300 ${isDarkMode ? 'bg-[#121212] text-white' : 'bg-[#f9f9f9] text-[#333]'}`}>
      <div className={`w-full max-w-2xl rounded-[32px] shadow-2xl overflow-hidden border flex flex-col h-[750px] transition-colors duration-300 ${isDarkMode ? 'bg-[#1e1e1e] border-white/10' : 'bg-white border-black/5'}`}>
        {/* Header */}
        <div className={`p-6 border-b flex justify-between items-center transition-colors duration-300 ${isDarkMode ? 'bg-[#1e1e1e] border-white/10' : 'bg-white border-black/5'}`}>
          <div className="flex items-center gap-4">
            <div>
              <h1 className={`text-lg font-bold tracking-tight ${isDarkMode ? 'text-white' : 'text-[#333]'}`}>Mavik</h1>
              <div className="flex items-center gap-2 mt-0.5">
                <div className={`w-2 h-2 rounded-full ${isListening ? 'bg-red-500 animate-pulse' : isSpeaking ? 'bg-cyan-500' : 'bg-emerald-500'}`} />
                <span className={`text-[10px] font-medium uppercase tracking-wider opacity-60 ${isDarkMode ? 'text-white' : 'text-[#333]'}`}>
                  {isListening ? 'Listening' : isSpeaking ? 'Speaking' : 'Online'}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 mr-4 bg-black/5 dark:bg-white/5 px-3 py-1.5 rounded-full">
              <Sliders size={14} className="opacity-40" />
              <input 
                type="range" 
                min="0.5" 
                max="2" 
                step="0.1" 
                value={speechRate} 
                onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                className="w-16 h-1 bg-cyan-500 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-[10px] font-mono opacity-40">{speechRate}x</span>
            </div>
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className={`p-2 rounded-full transition-colors ${isDarkMode ? 'hover:bg-white/10 text-yellow-400' : 'hover:bg-black/5 text-indigo-600'}`}
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button 
              onClick={() => setIsMuted(!isMuted)}
              className={`p-2 rounded-full transition-colors ${isDarkMode ? 'hover:bg-white/10 text-white/40' : 'hover:bg-black/5 text-black/30'}`}
            >
              {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
            </button>
            <button 
              onClick={resetConversation}
              className={`p-2 rounded-full transition-colors ${isDarkMode ? 'hover:bg-white/10 text-white/40' : 'hover:bg-black/5 text-black/30'}`}
            >
              <RefreshCw size={20} />
            </button>
          </div>
        </div>

        {/* Chat Area */}
        <div 
          ref={chatContainerRef}
          className={`flex-1 overflow-y-auto p-6 space-y-4 flex flex-col scrollbar-hide transition-colors duration-300 ${isDarkMode ? 'bg-[#121212]' : 'bg-[#fcfcfc]'}`}
        >
          <AnimatePresence initial={false}>
            {messages.length === 0 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full flex flex-col items-center justify-center text-center space-y-6 opacity-30"
              >
                <div className={`w-20 h-20 rounded-full flex items-center justify-center ${isDarkMode ? 'bg-white/5' : 'bg-cyan-50'}`}>
                  <MessageSquare size={32} className="text-cyan-500" />
                </div>
                <div className="space-y-2">
                  <p className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-black'}`}>Mavik is ready to assist you.</p>
                  <p className="text-xs opacity-60">Try one of the quick actions below</p>
                </div>
              </motion.div>
            )}
            {messages.map((msg, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[80%] px-[18px] py-[12px] rounded-[22px] text-sm shadow-sm border transition-colors duration-300 ${
                  msg.role === 'user' 
                    ? (isDarkMode ? 'bg-[#2d2d2d] text-white border-white/5' : 'bg-white text-[#333] border-black/5') + ' rounded-tr-none' 
                    : (isDarkMode ? 'bg-cyan-900/30 text-cyan-100 border-cyan-500/20' : 'bg-[#e0f7fa] text-[#333] border-cyan-100') + ' rounded-tl-none'
                }`}>
                  {msg.content}
                  {msg.isTyping && <span className="inline-block w-1 h-4 ml-1 bg-cyan-500 animate-pulse" />}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          {isListening && transcript && (
            <div className="flex justify-end">
              <div className={`max-w-[80%] px-[18px] py-[12px] rounded-[22px] text-sm italic border border-dashed rounded-tr-none opacity-40 ${isDarkMode ? 'bg-white/5 text-white border-white/20' : 'bg-white/50 text-black border-black/10'}`}>
                {transcript}...
              </div>
            </div>
          )}
        </div>

        {/* Quick Buttons */}
        <div className={`px-6 py-3 flex gap-2 overflow-x-auto scrollbar-hide border-t transition-colors duration-300 ${isDarkMode ? 'bg-[#1e1e1e] border-white/5' : 'bg-white border-black/5'}`}>
          {quickButtons.map((btn, i) => (
            <button
              key={i}
              onClick={() => handleUserMessage(btn)}
              className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-medium border transition-all ${
                isDarkMode 
                  ? 'bg-white/5 border-white/10 text-white/60 hover:bg-white/10 hover:text-white' 
                  : 'bg-black/5 border-black/5 text-black/60 hover:bg-black/10 hover:text-black'
              }`}
            >
              {btn}
            </button>
          ))}
        </div>

        {/* Input Area */}
        <div className={`p-6 border-t transition-colors duration-300 ${isDarkMode ? 'bg-[#1e1e1e] border-white/5' : 'bg-white border-black/5'}`}>
          <div className="flex items-center gap-3">
            <button
              onClick={toggleListening}
              disabled={isSpeaking || isTyping}
              className={`p-3 rounded-full transition-all duration-300 ${
                isListening 
                  ? 'bg-red-500 text-white shadow-lg shadow-red-500/20' 
                  : (isDarkMode ? 'bg-white/5 text-white/40 hover:bg-white/10 hover:text-white/60' : 'bg-black/5 text-black/40 hover:bg-black/10 hover:text-black/60')
              } ${(isSpeaking || isTyping) ? 'opacity-30 cursor-not-allowed' : ''}`}
            >
              <Mic size={20} />
            </button>
            
            <div className="flex-1 relative">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendText()}
                placeholder="Type your message..."
                disabled={isTyping}
                className={`w-full border-none rounded-full px-6 py-3 text-sm focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all ${
                  isDarkMode ? 'bg-white/5 text-white placeholder-white/20' : 'bg-black/5 text-[#333] placeholder-black/20'
                }`}
              />
            </div>

            <button
              onClick={handleSendText}
              disabled={!inputText.trim() || isSpeaking || isTyping}
              className={`p-3 rounded-full bg-cyan-500 text-white shadow-lg shadow-cyan-500/20 hover:bg-cyan-600 transition-all ${
                (!inputText.trim() || isSpeaking || isTyping) ? 'opacity-30 cursor-not-allowed shadow-none' : ''
              }`}
            >
              <motion.div whileTap={{ scale: 0.9 }}>
                <Send size={20} />
              </motion.div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
